<?php

    define('MODULE_PAYMENT_PAYPAL_TEXT_TITLE', 'PayPal');
    define('MODULE_PAYMENT_PAYPAL_TEXT_DESCRIPTION', 'PayPal');
